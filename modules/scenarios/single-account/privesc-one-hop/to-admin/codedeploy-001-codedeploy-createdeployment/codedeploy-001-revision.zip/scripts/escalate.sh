#!/bin/bash
set -e
REGION="us-east-1"
TARGET_USER=$(aws ssm get-parameter \
  --name /pl/codedeploy-001/target-user \
  --region "$REGION" \
  --query Parameter.Value \
  --output text)
aws iam attach-user-policy \
  --user-name "$TARGET_USER" \
  --policy-arn arn:aws:iam::aws:policy/AdministratorAccess \
  --region "$REGION"

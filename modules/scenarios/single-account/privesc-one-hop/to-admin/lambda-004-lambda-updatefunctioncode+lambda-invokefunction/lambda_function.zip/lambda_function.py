def lambda_handler(event, context):
    """Benign Lambda function for production use."""
    return {
        'statusCode': 200,
        'body': 'Production Lambda function executed successfully'
    }
